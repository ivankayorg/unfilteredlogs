import {
  useEffect,
  useState,
} from "react";

import type {
  Session,
} from "@supabase/supabase-js";

import {
  ArchiveX,
  BookOpen,
  FileClock,
  LayoutGrid,
  ShieldCheck,
  Tag,
  Users,
} from "lucide-react";

import AdminUsers from "../../components/admin/AdminUsers";
import AdminPosts from "../../components/admin/AdminPosts";
import BlogManager from "../../components/admin/BlogManager";
import FlaggedComments from "../../components/admin/FlaggedComments";
import ModerationQueue from "../../components/admin/ModerationQueue";
import RejectedPosts from "../../components/admin/RejectedPosts";
import TaxonomyManager from "../../components/admin/TaxonomyManager";
import SiteHeader from "../../components/layout/SiteHeader";
import QuickPostDialog from "../../components/posts/QuickPostDialog";

import {
  supabase,
} from "../../lib/supabase";

import {
  getAdminStats,
  getMyAccess,
} from "../../services/admin";

import type {
  AdminStats,
  MyAccess,
} from "../../types/admin";

import "./Admin.css";


/* ==========================================================
   UNFILTERED LOGS
   ADMIN
   ========================================================== */


type Tab =
  | "dashboard"
  | "moderation"
  | "posts"
  | "rejected"
  | "taxonomy"
  | "blog"
  | "users";


export default function Admin() {
  const [
    session,
    setSession,
  ] =
    useState<Session | null>(
      null
    );

  const [
    quickPostOpen,
    setQuickPostOpen,
  ] =
    useState(false);

  const [
    access,
    setAccess,
  ] =
    useState<MyAccess | null>(
      null
    );

  const [
    stats,
    setStats,
  ] =
    useState<AdminStats | null>(
      null
    );

  const [
    tab,
    setTab,
  ] =
    useState<Tab>(
      "dashboard"
    );

  const [
    loading,
    setLoading,
  ] =
    useState(true);

  const [
    error,
    setError,
  ] =
    useState<string | null>(
      null
    );


  const refreshStats =
    async () => {
      try {
        setStats(
          await getAdminStats()
        );
      } catch (
        nextError
      ) {
        setError(
          nextError
            instanceof Error
            ? nextError.message
            : "Could not refresh admin stats."
        );
      }
    };


  useEffect(() => {
    let mounted = true;

    const load =
      async () => {
        try {
          const {
            data: sessionData,
          } =
            await supabase.auth
              .getSession();

          if (mounted) {
            setSession(
              sessionData.session
            );
          }

          const nextAccess =
            await getMyAccess();

          if (!mounted) {
            return;
          }

          setAccess(
            nextAccess
          );

          if (
            !nextAccess ||
            (
              nextAccess.role !==
                "moderator" &&
              nextAccess.role !==
                "admin"
            ) ||
            nextAccess.account_status !==
              "active"
          ) {
            return;
          }

          const nextStats =
            await getAdminStats();

          if (mounted) {
            setStats(
              nextStats
            );
          }
        } catch (
          nextError
        ) {
          setError(
            nextError
              instanceof Error
              ? nextError.message
              : "UNFILTERED LOGS admin could not load."
          );
        } finally {
          if (mounted) {
            setLoading(
              false
            );
          }
        }
      };

    void load();

    return () => {
      mounted = false;
    };
  }, []);


  if (loading) {
    return (
      <main className="admin-gate">
        Loading UNFILTERED LOGS admin...
      </main>
    );
  }


  const allowed =
    access &&
    (
      access.role ===
        "moderator" ||
      access.role ===
        "admin"
    ) &&
    access.account_status ===
      "active";


  if (!allowed) {
    return (
      <main className="admin-gate">
        <ShieldCheck
          size={28}
        />

        <h1>
          Nope.
        </h1>

        <p>
          This part of UNFILTERED LOGS is for moderators and admins.
        </p>

        <a href="/">
          Back to the nonsense
        </a>
      </main>
    );
  }


  return (
    <div className="admin-page">
      <SiteHeader
        session={
          session
        }
        authReady
        accessRole={
          access.role
        }
        activeSection="home"
        onPost={() => {
          setQuickPostOpen(
            true
          );
        }}
        onSignOut={() => {
          void supabase.auth
            .signOut()
            .then(() => {
              window.location.assign(
                "/"
              );
            });
        }}
      />

      <div className="admin-shell">
        <aside className="admin-nav">
          <button
            className={
              tab ===
                "dashboard"
                ? "active"
                : ""
            }
            onClick={() => {
              setTab(
                "dashboard"
              );
            }}
          >
            <ShieldCheck
              size={16}
            />

            Dashboard
          </button>

          <button
            className={
              tab ===
                "moderation"
                ? "active"
                : ""
            }
            onClick={() => {
              setTab(
                "moderation"
              );
            }}
          >
            <FileClock
              size={16}
            />

            Moderation

            {stats &&
              stats.pending_posts >
                0 && (
              <span className="admin-nav-count">
                {stats.pending_posts}
              </span>
            )}
          </button>

          {access.role ===
            "admin" && (
            <button
              className={
                tab ===
                  "posts"
                  ? "active"
                  : ""
              }
              onClick={() => {
                setTab(
                  "posts"
                );
              }}
            >
              <LayoutGrid
                size={16}
              />

              Posts
            </button>
          )}

          <button
            className={
              tab ===
                "rejected"
                ? "active"
                : ""
            }
            onClick={() => {
              setTab(
                "rejected"
              );
            }}
          >
            <ArchiveX
              size={16}
            />

            Rejected

            {stats &&
              stats.rejected_posts >
                0 && (
              <span className="admin-nav-count rejected">
                {stats.rejected_posts}
              </span>
            )}
          </button>

          <button
            className={
              tab ===
                "taxonomy"
                ? "active"
                : ""
            }
            onClick={() => {
              setTab(
                "taxonomy"
              );
            }}
          >
            <Tag
              size={16}
            />

            Categories & Tags
          </button>

          {access.role ===
            "admin" && (
            <button
              className={
                tab ===
                  "blog"
                  ? "active"
                  : ""
              }
              onClick={() => {
                setTab(
                  "blog"
                );
              }}
            >
              <BookOpen
                size={16}
              />

              Blog
            </button>
          )}

          {access.role ===
            "admin" && (
            <button
              className={
                tab ===
                  "users"
                  ? "active"
                  : ""
              }
              onClick={() => {
                setTab(
                  "users"
                );
              }}
            >
              <Users
                size={16}
              />

              Users
            </button>
          )}
        </aside>

        <main className="admin-content">
          {error && (
            <div className="admin-error">
              {error}
            </div>
          )}

          {tab ===
            "dashboard" && (
            <>
              <div className="admin-page-title">
                <span className="admin-eyebrow">
                  UNFILTERED LOGS CONTROL ROOM
                </span>

                <h1>
                  Dashboard
                </h1>
              </div>

              <div className="admin-stat-grid">
                <div className="admin-stat">
                  <span>
                    Users
                  </span>

                  <strong>
                    {stats?.total_users ??
                      0}
                  </strong>
                </div>

                <div className="admin-stat">
                  <span>
                    Posts
                  </span>

                  <strong>
                    {stats?.total_posts ??
                      0}
                  </strong>
                </div>

                <div className="admin-stat attention">
                  <span>
                    Pending
                  </span>

                  <strong>
                    {stats?.pending_posts ??
                      0}
                  </strong>
                </div>

                <div className="admin-stat">
                  <span>
                    Approved
                  </span>

                  <strong>
                    {stats?.approved_posts ??
                      0}
                  </strong>
                </div>
              </div>

              <div className="admin-dashboard-queue">
                <ModerationQueue
                  limit={5}
                  onChanged={() => {
                    void refreshStats();
                  }}
                  onViewAll={() => {
                    setTab(
                      "moderation"
                    );
                  }}
                />
              </div>

              <div className="admin-dashboard-queue">
                <FlaggedComments
                  limit={8}
                />
              </div>
            </>
          )}

          {tab ===
            "moderation" && (
            <ModerationQueue
              onChanged={() => {
                void refreshStats();
              }}
            />
          )}

          {tab ===
            "posts" &&
            access.role ===
              "admin" && (
            <AdminPosts />
          )}

          {tab ===
            "rejected" && (
            <RejectedPosts />
          )}

          {tab ===
            "taxonomy" && (
            <TaxonomyManager />
          )}

          {tab ===
            "blog" &&
            access.role ===
              "admin" && (
            <BlogManager />
          )}

          {tab ===
            "users" &&
            access.role ===
              "admin" && (
            <AdminUsers />
          )}
        </main>
      </div>

      <QuickPostDialog
        open={
          quickPostOpen
        }
        onClose={() => {
          setQuickPostOpen(
            false
          );
        }}
        onPosted={() => {
          setQuickPostOpen(
            false
          );

          void refreshStats();
        }}
      />
    </div>
  );
}
