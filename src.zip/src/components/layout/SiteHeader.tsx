import { useState } from "react";
import type { Session } from "@supabase/supabase-js";
import {
  Menu,
  Plus,
  Search,
  UserRound,
  X,
} from "lucide-react";
import type { UserRole } from "../../types/admin";

/* ==========================================================
   HEADER 001
   SHARED UNFILTERED LOGS MASTHEAD
   ========================================================== */

type ActiveSection = "home" | "blog";

type Props = {
  session: Session | null;
  authReady: boolean;
  accessRole: UserRole | null;
  activeSection: ActiveSection;
  onPost: () => void;
  onSignOut: () => void;
};

export function UnfilteredLogsLogo() {
  return (
    <a className="roffle-logo" href="/" aria-label="Unfiltered Logs home">
      <span className="logo-mark">UL</span>
      <span className="logo-word">UNFILTERED LOGS</span>
    </a>
  );
}

export default function SiteHeader({
  session,
  authReady,
  accessRole,
  activeSection,
  onPost,
  onSignOut,
}: Props) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const provider = session?.user.app_metadata?.provider;
  const providerLabel = provider === "google" ? "Google" : provider === "discord" ? "Discord" : provider ? String(provider) : "Account";
  const userLabel =
    session?.user.user_metadata?.full_name ??
    session?.user.user_metadata?.preferred_username ??
    session?.user.user_metadata?.user_name ??
    session?.user.email ??
    "Signed in";

  const handlePost = () => {
    setMobileOpen(false);
    onPost();
  };

  return (
    <>
      <header className="site-header">
        <div className="header-shell">
          <UnfilteredLogsLogo />

          <span className="header-live"><i /> LIVE FEED</span>

          <nav className="desktop-nav">
            <a className={activeSection === "home" ? "nav-active" : ""} href="/">Logs</a>
            <a className={activeSection === "blog" ? "nav-active" : ""} href="/blog">Editorial</a>
          </nav>

          <div className="header-actions">
            <button className="icon-button" type="button" aria-label="Search">
              <Search size={18} />
            </button>

            <button className="quick-post-trigger" type="button" onClick={handlePost}>
              <Plus size={15} /> New log
            </button>

            {authReady && (session ? (
              <>
                <div className="header-user" title={`${userLabel} via ${providerLabel}`}>
                  <span className="header-user-icon"><UserRound size={15} /></span>
                  <span className="header-user-copy"><strong>{userLabel}</strong><small>{providerLabel}</small></span>
                </div>

                {(accessRole === "moderator" || accessRole === "admin") && (
                  <a className="header-admin-link" href="/admin">Admin</a>
                )}

                <button className="header-signout" type="button" onClick={onSignOut}>Sign out</button>
              </>
            ) : (
              <a className="login-link" href="/login">Sign in</a>
            ))}

            <button className="mobile-menu" type="button" onClick={() => setMobileOpen((current) => !current)} aria-label="Menu">
              {mobileOpen ? <X size={21} /> : <Menu size={21} />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <nav className="mobile-nav">
            <a href="/">Logs</a>
            <a href="/blog">Editorial</a>
            <button className="mobile-post-trigger" type="button" onClick={handlePost}><Plus size={15} /> New log</button>

            {authReady && (session ? (
              <div className="mobile-auth">
                <div className="mobile-auth-copy"><strong>{userLabel}</strong><small>Signed in with {providerLabel}</small></div>
                {(accessRole === "moderator" || accessRole === "admin") && <a href="/admin">Admin</a>}
                <button type="button" onClick={onSignOut}>Sign out</button>
              </div>
            ) : <a href="/login">Sign in</a>)}
          </nav>
        )}
      </header>
    </>
  );
}
