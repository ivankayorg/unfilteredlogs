import {
  lazy,
  Suspense,
  useEffect,
  useState,
} from "react";

import {
  ArrowRight,
  CircleDot,
  LockKeyhole,
  MessageSquareText,
  Radio,
  Sparkles,
} from "lucide-react";

import { supabase } from "./lib/supabase";
import PasswordAuthForm from "./components/auth/PasswordAuthForm";
import "./AppV2.css";

const AppV2 = lazy(() => import("./AppV2"));
const Admin = lazy(() => import("./pages/admin/Admin"));
const Blog = lazy(() => import("./pages/blog/Blog"));

/* ==========================================================
   APP 001
   UNFILTERED LOGS ENTRY + ROUTING
   ========================================================== */

function PrototypeLoading() {
  return (
    <main className="ul-loading-screen">
      <span className="ul-loading-dot" />
      <span>Opening the logs...</span>
    </main>
  );
}

function UnfilteredLogsLogo() {
  return (
    <a className="roffle-logo" href="/" aria-label="Unfiltered Logs home">
      <span className="logo-mark">UL</span>
      <span className="logo-word">UNFILTERED LOGS</span>
    </a>
  );
}

function GoogleLogo() {
  return (
    <svg className="auth-provider-logo" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#4285F4" d="M21.6 12.23c0-.71-.06-1.4-.18-2.07H12v3.92h5.38a4.6 4.6 0 0 1-1.99 3.02v2.51h3.22c1.89-1.74 2.99-4.31 2.99-7.38Z" />
      <path fill="#34A853" d="M12 22c2.7 0 4.97-.89 6.62-2.4l-3.22-2.51c-.9.6-2.04.96-3.4.96-2.6 0-4.8-1.75-5.59-4.11H3.08v2.58A10 10 0 0 0 12 22Z" />
      <path fill="#FBBC05" d="M6.41 13.94A6.01 6.01 0 0 1 6.1 12c0-.67.11-1.32.31-1.94V7.48H3.08A10 10 0 0 0 2 12c0 1.61.39 3.13 1.08 4.52l3.33-2.58Z" />
      <path fill="#EA4335" d="M12 5.95c1.47 0 2.79.5 3.82 1.49l2.87-2.87C16.96 2.96 14.7 2 12 2a10 10 0 0 0-8.92 5.48l3.33 2.58C7.2 7.7 9.4 5.95 12 5.95Z" />
    </svg>
  );
}

function DiscordLogo() {
  return (
    <svg className="auth-provider-logo discord-logo" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="currentColor" d="M19.54 5.32A16.7 16.7 0 0 0 15.44 4l-.5 1.03a15.3 15.3 0 0 0-5.87 0L8.56 4a16.8 16.8 0 0 0-4.11 1.33C1.85 9.17 1.15 12.9 1.5 16.58a16.5 16.5 0 0 0 5.03 2.54l1.2-1.65a10.5 10.5 0 0 1-1.89-.9l.46-.35a12 12 0 0 0 11.4 0l.47.35c-.6.35-1.23.65-1.9.9l1.2 1.65a16.5 16.5 0 0 0 5.03-2.54c.4-4.27-.68-7.97-2.46-11.26ZM8.34 14.72c-1.08 0-1.97-.99-1.97-2.2 0-1.22.87-2.2 1.97-2.2 1.1 0 1.99 1 1.97 2.2 0 1.21-.87 2.2-1.97 2.2Zm7.32 0c-1.08 0-1.97-.99-1.97-2.2 0-1.22.87-2.2 1.97-2.2 1.1 0 1.99 1 1.97 2.2 0 1.21-.87 2.2-1.97 2.2Z" />
    </svg>
  );
}

/* ==========================================================
   APP 002
   AUTH FRONT END
   ========================================================== */

function LoginPage() {
  const [signingIn, setSigningIn] = useState<"google" | "discord" | null>(null);
  const [signedIn, setSignedIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    void supabase.auth.getSession().then(({ data }) => {
      if (active) setSignedIn(Boolean(data.session));
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (active) setSignedIn(Boolean(session));
    });

    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);

  const signInWithProvider = async (provider: "google" | "discord") => {
    setSigningIn(provider);
    setAuthError(null);

    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: `${window.location.origin}/` },
    });

    if (error) {
      setAuthError(error.message);
      setSigningIn(null);
    }
  };

  return (
    <div className="ul-auth-page">
      <header className="ul-auth-header">
        <UnfilteredLogsLogo />
        <a href="/" className="ul-auth-browse">Browse without signing in</a>
      </header>

      <main className="ul-auth-main">
        <section className="ul-auth-story">
          <span className="ul-eyebrow"><Radio size={13} /> LIVE / MOSTLY UNHELPFUL</span>
          <h1>The internet<br />without the<br /><em>press release.</em></h1>
          <p>
            Posts, clips, images, links, and questionable observations from people
            who still remember when the web felt human.
          </p>

          <div className="ul-auth-signals">
            <span><CircleDot size={13} /> post what you found</span>
            <span><MessageSquareText size={13} /> say what you mean</span>
            <span><Sparkles size={13} /> keep it weird</span>
          </div>
        </section>

        <section className="ul-login-panel">
          <div className="ul-login-panel-head">
            <span>ACCOUNT ACCESS</span>
            <LockKeyhole size={19} />
          </div>

          <h2>Sign in to the logs.</h2>
          <p>No onboarding maze. Pick a door and get back to the internet.</p>

          {signedIn && (
            <button className="ul-continue-button" type="button" onClick={() => window.location.assign("/")}>
              Continue to Unfiltered Logs <ArrowRight size={16} />
            </button>
          )}

          <button className="ul-google-button" type="button" disabled={signingIn !== null} onClick={() => void signInWithProvider("google")}>
            <GoogleLogo /> {signingIn === "google" ? "Opening Google..." : "Continue with Google"}
          </button>

          <button className="ul-discord-button" type="button" disabled={signingIn !== null} onClick={() => void signInWithProvider("discord")}>
            <DiscordLogo /> {signingIn === "discord" ? "Opening Discord..." : "Continue with Discord"}
          </button>

          <div className="ul-auth-divider"><span>or email</span></div>
          <PasswordAuthForm />

          {authError && <div className="ul-auth-error">{authError}</div>}

          <a className="ul-lurk-link" href="/">
            Just lurk for now <ArrowRight size={15} />
          </a>
        </section>
      </main>
    </div>
  );
}

/* ==========================================================
   APP 003
   ROUTES
   ========================================================== */

function App() {
  const path = window.location.pathname.toLowerCase();

  if (path === "/login" || path === "/signin") return <LoginPage />;

  if (path === "/blog" || path.startsWith("/blog/")) {
    return <Suspense fallback={<PrototypeLoading />}><Blog /></Suspense>;
  }

  if (path === "/admin" || path.startsWith("/admin/")) {
    return <Suspense fallback={<PrototypeLoading />}><Admin /></Suspense>;
  }

  return <Suspense fallback={<PrototypeLoading />}><AppV2 /></Suspense>;
}

export default App;
